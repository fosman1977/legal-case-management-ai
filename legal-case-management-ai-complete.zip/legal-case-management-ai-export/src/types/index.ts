export interface Document {
  id: string;
  caseId: string;
  name: string;
  type: string;
  uploadDate: string;
  size: number;
  content: string;
}

export interface Person {
  name: string;
  role: string;
  mentions: number;
}

export interface Organization {
  name: string;
  type: string;
  mentions: number;
}

export interface Location {
  name: string;
  mentions: number;
}

export interface DateEntity {
  date: string;
  context: string;
  importance: 'high' | 'medium' | 'low';
}

export interface MonetaryAmount {
  amount: number;
  currency: string;
  context: string;
}

export interface LegalConcept {
  concept: string;
  relevance: number;
}

export interface Entities {
  persons: Person[];
  organizations: Organization[];
  locations: Location[];
  dates: DateEntity[];
  monetaryAmounts: MonetaryAmount[];
  legalConcepts: LegalConcept[];
}

export interface Case {
  id: string;
  name: string;
  client: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  status: 'active' | 'closed' | 'pending';
  documents: Document[];
  entities: Entities;
  chronology: any[];
  keyTerms: string[];
  notes: UserNote[];
  orders: CourtOrder[];
}

export interface UserNote {
  id: string;
  caseId: string;
  type: 'note' | 'memo' | 'meeting' | 'audio' | 'video' | 'working-paper';
  title: string;
  content: string;
  transcript?: string;
  fileUrl?: string;
  createdAt: string;
  updatedAt: string;
  tags: string[];
  isUserGenerated: boolean;
}

export interface Deadline {
  id: string;
  description: string;
  dueDate: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'completed' | 'overdue';
  notes?: string;
  relatedOrderId?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'in-progress' | 'completed';
  dueDate?: string;
  relatedOrderId?: string;
}

export interface CourtOrder {
  id: string;
  caseId: string;
  orderNumber: string;
  courtName: string;
  judgeNames: string[];
  orderDate: string;
  receivedDate: string;
  orderType: string;
  title: string;
  content: string;
  extractedDeadlines: Deadline[];
  extractedTasks: Task[];
  status: 'pending' | 'reviewed' | 'actioned';
}

export interface GlobalDeadline extends Deadline {
  caseId: string;
  caseName: string;
}
