class UnifiedAIClient {
  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch('http://localhost:3002/api/health');
      return response.ok;
    } catch {
      return false;
    }
  }

  async extractEntities(content: string): Promise<any> {
    // Mock implementation - returns sample data
    return {
      persons: [
        { name: "John Smith", role: "Client", mentions: 5 },
        { name: "Jane Doe", role: "Opposing Party", mentions: 3 }
      ],
      organizations: [
        { name: "ABC Corporation", type: "Company", mentions: 2 }
      ],
      locations: [
        { name: "New York", mentions: 4 }
      ],
      dates: [
        { date: "2024-01-15", context: "Contract signing", importance: "high" as const }
      ],
      monetaryAmounts: [
        { amount: 50000, currency: "USD", context: "Settlement amount" }
      ],
      legalConcepts: [
        { concept: "Breach of Contract", relevance: 0.9 }
      ]
    };
  }

  async extractDeadlines(content: string): Promise<any[]> {
    // Mock implementation
    return [
      {
        id: Date.now().toString(),
        description: "File response to motion",
        dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        priority: "high" as const,
        status: "pending" as const,
        notes: "Extracted from court order"
      }
    ];
  }

  async transcribeAudio(audioBlob: Blob): Promise<string> {
    // Mock transcription
    return "This is a mock transcription of the audio recording. In a real implementation, this would use speech-to-text AI.";
  }
}

export const unifiedAIClient = new UnifiedAIClient();
