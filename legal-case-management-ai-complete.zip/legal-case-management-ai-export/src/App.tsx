import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { 
  FileText, Calendar, MessageSquare, Settings, Menu, X, 
  Users, BookOpen, ClipboardList, Brain, Home 
} from 'lucide-react';
import CaseList from './components/CaseList';
import CaseView from './components/CaseView';
import GlobalProceduralCalendar from './components/GlobalProceduralCalendar';
import UserNotesManager from './components/UserNotesManager';
import OrdersDirectionsManager from './components/OrdersDirectionsManager';
import AIAnalysisHub from './components/AIAnalysisHub';
import './App.css';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <Router>
      <div className="app">
        <aside className={`sidebar ${sidebarOpen ? 'open' : 'closed'}`}>
          <div className="sidebar-header">
            <h1>{sidebarOpen ? '⚖️ Legal AI Pro' : '⚖️'}</h1>
            <button 
              className="sidebar-toggle"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
          
          <nav className="sidebar-nav">
            <Link to="/" className="nav-item">
              <Home size={20} />
              {sidebarOpen && <span>Dashboard</span>}
            </Link>
            
            <Link to="/cases" className="nav-item">
              <FileText size={20} />
              {sidebarOpen && <span>Cases</span>}
            </Link>
            
            <Link to="/calendar" className="nav-item">
              <Calendar size={20} />
              {sidebarOpen && <span>Deadlines</span>}
            </Link>
            
            <Link to="/notes" className="nav-item">
              <BookOpen size={20} />
              {sidebarOpen && <span>Notes</span>}
            </Link>
            
            <Link to="/orders" className="nav-item">
              <ClipboardList size={20} />
              {sidebarOpen && <span>Orders</span>}
            </Link>
            
            <Link to="/ai-analysis" className="nav-item">
              <Brain size={20} />
              {sidebarOpen && <span>AI Analysis</span>}
            </Link>
            
            <a 
              href="http://localhost:3002" 
              target="_blank" 
              rel="noopener noreferrer"
              className="nav-item"
            >
              <MessageSquare size={20} />
              {sidebarOpen && <span>AI Chat</span>}
            </a>
          </nav>
        </aside>
        
        <main className="main-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/cases" element={<CaseList />} />
            <Route path="/case/:id/*" element={<CaseView />} />
            <Route path="/calendar" element={<GlobalProceduralCalendar />} />
            <Route path="/notes" element={<UserNotesManager caseId="" />} />
            <Route path="/orders" element={<OrdersDirectionsManager caseId="" />} />
            <Route path="/ai-analysis" element={<AIAnalysisHub />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

// Dashboard component
const Dashboard = () => {
  const [cases] = useState(() => {
    return JSON.parse(localStorage.getItem('cases') || '[]');
  });

  return (
    <div className="dashboard">
      <h1>Legal Case Management AI</h1>
      <div className="dashboard-stats">
        <div className="stat-card">
          <h3>{cases.length}</h3>
          <p>Active Cases</p>
        </div>
        <div className="stat-card">
          <h3>0</h3>
          <p>Pending Deadlines</p>
        </div>
        <div className="stat-card">
          <h3>0</h3>
          <p>Documents</p>
        </div>
      </div>
      <div className="quick-actions">
        <Link to="/cases" className="btn btn-primary">
          <FileText size={20} />
          Manage Cases
        </Link>
        <a href="http://localhost:3002" target="_blank" className="btn btn-secondary">
          <MessageSquare size={20} />
          Open AI Chat
        </a>
      </div>
    </div>
  );
};

export default App;
