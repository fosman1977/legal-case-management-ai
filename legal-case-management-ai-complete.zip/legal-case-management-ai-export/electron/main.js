const { app, BrowserWindow, Menu, shell, dialog } = require('electron');
const path = require('path');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1000,
    minHeight: 600,
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      webSecurity: false
    }
  });

  // Load the built app
  const isDev = process.env.NODE_ENV === 'development';
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile('dist/index.html');
  }

  // Handle external links
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

// Create menu
const template = [
  {
    label: 'File',
    submenu: [
      { 
        label: 'New Case',
        accelerator: 'CmdOrCtrl+N',
        click: () => mainWindow.webContents.executeJavaScript(`
          window.location.hash = '/cases';
        `)
      },
      { type: 'separator' },
      { role: 'quit' }
    ]
  },
  {
    label: 'View',
    submenu: [
      { role: 'reload' },
      { role: 'toggleDevTools' },
      { type: 'separator' },
      { role: 'resetZoom' },
      { role: 'zoomIn' },
      { role: 'zoomOut' }
    ]
  },
  {
    label: 'AI',
    submenu: [
      {
        label: 'Open AI Chat',
        click: () => shell.openExternal('http://localhost:3002')
      },
      {
        label: 'AI Services Status',
        click: () => {
          dialog.showMessageBox(mainWindow, {
            title: 'AI Services',
            message: 'To start AI services, run "npm run ai" in Terminal',
            buttons: ['OK']
          });
        }
      }
    ]
  }
];

Menu.setApplicationMenu(Menu.buildFromTemplate(template));
