#!/bin/bash

echo "🚀 Installing Legal Case Management AI System..."

# Check requirements
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is required but not installed."
    echo "Please install Node.js from: https://nodejs.org/"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo "❌ Docker is required for AI features."
    echo "Please install Docker Desktop from: https://www.docker.com/products/docker-desktop"
    echo "You can continue without Docker, but AI features won't be available."
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Build the application
echo "🔨 Building application..."
npm run build

echo "✅ Installation complete!"
echo ""
echo "🚀 To start the application:"
echo "   npm run electron-dev    # Development mode"
echo "   npm run dist           # Build desktop app"
echo ""
echo "🤖 To start AI services:"
echo "   npm run ai            # Start AI services"
echo "   Open: http://localhost:3002"
echo ""
echo "🎉 Your Legal Case Management AI is ready!"
