#!/bin/bash

echo "🚀 Deploying Legal Case Management AI to GitHub..."

# Check if GitHub CLI is available
if command -v gh &> /dev/null; then
    echo "📱 GitHub CLI detected, creating repository..."
    
    # Create repository using GitHub CLI
    gh repo create legal-case-management-ai --public --description "Professional AI-powered legal case management desktop application" --clone=false
    
    REPO_URL="https://github.com/$(gh auth status | grep "Logged in" | awk '{print $7}' | sed 's/[()]//g')/legal-case-management-ai.git"
else
    echo "📝 Please create a GitHub repository manually:"
    echo "1. Go to: https://github.com/new"
    echo "2. Repository name: legal-case-management-ai"
    echo "3. Description: Professional AI-powered legal case management desktop application"
    echo "4. Make it public (recommended)"
    echo "5. Don't initialize with README (we have one)"
    echo ""
    read -p "Enter your GitHub username: " USERNAME
    REPO_URL="https://github.com/$USERNAME/legal-case-management-ai.git"
fi

# Initialize git and push
echo "📤 Initializing git repository..."
git init
git add .
git commit -m "🎉 Complete Legal Case Management AI System

Features included:
✅ Professional case management with document upload
✅ AI-powered entity extraction and document analysis
✅ User notes with audio/video recording and transcription
✅ Court orders with automatic deadline extraction  
✅ Global procedural calendar showing all deadlines
✅ OpenWebUI integration for AI chat and analysis
✅ Electron desktop application
✅ Responsive professional UI
✅ Docker configuration for AI services
✅ Automated GitHub Actions builds

🤖 Generated with Claude Code
Co-Authored-By: Claude <noreply@anthropic.com>"

git branch -M main
git remote add origin "$REPO_URL"

echo "📤 Pushing to GitHub..."
git push -u origin main

echo ""
echo "🎉 SUCCESS! Your Legal Case Management AI is now on GitHub!"
echo ""
echo "🔗 Repository URL: $REPO_URL"
echo ""
echo "🚀 Next steps for your device:"
echo "1. On your Mac, run these commands:"
echo "   cd ~/Documents"
echo "   git clone $REPO_URL"
echo "   cd legal-case-management-ai"
echo "   ./install.sh"
echo ""
echo "🔄 For auto-sync, run:"
echo "   ./sync-config.sh setup     # One-time setup"
echo "   ./sync-config.sh watch     # Start auto-sync"
echo ""
echo "✨ Your complete legal AI system is ready!"
