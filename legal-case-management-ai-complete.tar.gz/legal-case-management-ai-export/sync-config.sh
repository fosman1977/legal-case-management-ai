#!/bin/bash

# Auto-sync configuration for Legal Case Management AI
# This script helps sync changes between development environment and local device

REPO_URL="https://github.com/YOUR-USERNAME/legal-case-management-ai.git"
LOCAL_PATH="$HOME/Documents/legal-case-management"

setup_sync() {
    echo "🔧 Setting up auto-sync..."
    
    # Create local directory if it doesn't exist
    mkdir -p "$LOCAL_PATH"
    cd "$LOCAL_PATH"
    
    # Initialize git if not already done
    if [ ! -d ".git" ]; then
        echo "📥 Cloning repository..."
        git clone "$REPO_URL" .
    else
        echo "🔄 Repository already exists, pulling latest changes..."
        git pull origin main
    fi
    
    # Install dependencies
    echo "📦 Installing dependencies..."
    npm install
    
    echo "✅ Auto-sync setup complete!"
}

sync_changes() {
    echo "🔄 Syncing latest changes..."
    cd "$LOCAL_PATH"
    
    # Pull latest changes
    git pull origin main
    
    # Install any new dependencies
    npm install
    
    echo "✅ Sync complete!"
    echo "🚀 Run 'npm run electron-dev' to start the application"
}

watch_changes() {
    echo "👀 Starting auto-sync watcher..."
    echo "This will check for updates every 30 seconds..."
    echo "Press Ctrl+C to stop"
    
    while true; do
        cd "$LOCAL_PATH"
        
        # Check if there are remote changes
        git fetch origin
        LOCAL=$(git rev-parse HEAD)
        REMOTE=$(git rev-parse origin/main)
        
        if [ "$LOCAL" != "$REMOTE" ]; then
            echo "📥 New changes detected, syncing..."
            sync_changes
            
            # Notify user (macOS)
            if command -v osascript &> /dev/null; then
                osascript -e 'display notification "Legal AI system updated!" with title "Auto-Sync"'
            fi
        fi
        
        sleep 30
    done
}

case "$1" in
    "setup")
        setup_sync
        ;;
    "sync")
        sync_changes
        ;;
    "watch")
        watch_changes
        ;;
    *)
        echo "Legal Case Management AI - Auto-Sync Tool"
        echo ""
        echo "Usage:"
        echo "  $0 setup     # Initial setup and clone repository"
        echo "  $0 sync      # Sync latest changes once"
        echo "  $0 watch     # Start auto-sync watcher (checks every 30s)"
        echo ""
        echo "Examples:"
        echo "  $0 setup                    # First time setup"
        echo "  $0 sync                     # Get latest updates"
        echo "  $0 watch                    # Auto-sync in background"
        ;;
esac
