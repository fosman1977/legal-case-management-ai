# Legal Case Management AI - Device Setup Guide

Complete setup instructions for your Mac device.

## Method 1: Automatic Setup (Recommended)

### Step 1: Deploy to GitHub
```bash
cd /path/to/legal-case-management-ai-export
./deploy-to-github.sh
```

### Step 2: Setup on Your Mac
```bash
cd ~/Documents
git clone https://github.com/YOUR-USERNAME/legal-case-management-ai.git
cd legal-case-management-ai
./install.sh
```

### Step 3: Start Application
```bash
npm run electron-dev
```

### Step 4: Enable Auto-Sync (Optional)
```bash
./sync-config.sh setup
./sync-config.sh watch
```

## Method 2: Manual Setup

### Download and Extract
1. Go to your GitHub repository
2. Click "Code" → "Download ZIP"
3. Extract to `~/Documents/legal-case-management-ai/`

### Install
```bash
cd ~/Documents/legal-case-management-ai
npm install
npm run build
npm run electron-dev
```

## AI Features Setup

### Start AI Services
```bash
npm run ai
```

### Access AI Chat
Open: http://localhost:3002

### Install AI Models (Optional)
The system will download models automatically when first used.

## Features Available

✅ **Case Management** - Professional case organization
✅ **Document Analysis** - AI-powered document processing  
✅ **Audio/Video Notes** - Client meeting recordings with transcription
✅ **Court Orders** - Automatic deadline extraction
✅ **Global Calendar** - All deadlines in one view
✅ **AI Chat** - Document analysis and legal research
✅ **Desktop App** - Native macOS application

## Troubleshooting

### Port Issues
If port 5173 is in use:
```bash
lsof -ti:5173 | xargs kill -9
```

### Docker Issues
```bash
docker system prune -a
npm run ai
```

### Auto-Sync Not Working
```bash
./sync-config.sh setup
```

## Development Sync

To keep your local version updated with changes made in the development environment:

1. **One-time sync**: `./sync-config.sh sync`
2. **Auto-sync**: `./sync-config.sh watch` (runs in background)
3. **Manual check**: `git pull origin main`

## Support

- Check logs: `npm run ai-logs`  
- Restart services: `npm run ai-stop && npm run ai`
- Rebuild app: `npm run clean && npm install && npm run build`

---

🎉 **Your professional Legal Case Management AI system is ready!**

Made with ❤️ for legal professionals worldwide.
